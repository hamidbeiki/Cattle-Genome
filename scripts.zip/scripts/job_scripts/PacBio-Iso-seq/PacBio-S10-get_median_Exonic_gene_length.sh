### IMPORTANT: to speedup, this script need to be run on a compute node (i.e, run on a job script or reques
##  a compute node via: salloc -N1 -p brief-low -n 70 -t 015:00:00

module lod python/3.6.3-u4oaxsb
module load py-pandas/0.23.4-py3-sx6iffy

TISSUE="${1}"
CORRECTION_METHOD="${2}"

awk '$3=="exon"' ${TISSUE}_${CORRECTION_METHOD}_corrected_Flnc.eval.collapsed.gff | sed 's/gene\_id \"//g;s/\"\; /\t/g' | awk '{print $9, $4, $5}' >out
# to get whole gene length included intronic regions, issue: 
#sed 's/gene\_id \"//g;s/"; /\t/g' ${TISSUE}_${CORRECTION_METHOD}_corrected_Flnc.eval.collapsed.gff | awk '$3=="transcript"{print $9, $4, $5}'>out2

median_gene_length=$(python PacBio-S10-get_median_Exonic_gene_length.py out)

echo $TISSUE $CORRECTION_METHOD $median_gene_length
