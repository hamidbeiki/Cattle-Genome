for i in $(ls | grep 'cupkace' | grep fa$ | grep -v chim)
	do 
	   tissue=$(echo $i | rev | cut -c 38- | rev)
	   cat ${i} ${tissue}_proovread_chimeric_reads_cupkace_corrected.fa >${tissue}_fmlrc_proovread_cupcake_corrected_reads.fasta
done;
