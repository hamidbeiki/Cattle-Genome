for i in $(awk '{print $3}' tissue-lib-info | grep -v -f incorrect_protocol_tissues | grep  -v -f remainig |  sort | uniq);
 do
   echo "working on $i"
   awk -v tissue="${i}" '$3==tissue {print $1}' tissue-lib-info | grep -v -f incorrect_protocol_libs | grep -v -f pooled_libs | awk '{print $1"_s1_p0.flnc.fasta"}'>tmp
   { xargs cat < tmp; } >${i}.flnc.fasta
   rm -r tmp
   echo "$i is done"
done;
