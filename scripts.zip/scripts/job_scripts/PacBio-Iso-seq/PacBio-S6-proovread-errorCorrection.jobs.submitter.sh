### simply issue: bash proovread-errorCorrection.jobs.submitter.sh <your tissue of intrest, e.g. Thalamus>
TISSUE="${1}"
max=$(ls | grep  ${TISSUE} | grep fa$ | grep [0-9].fa$  | tail -n 1 | sed 's/.*\-//g;s/\.fa//g' | sed 's/^0//g')
for i in $(seq 1 $max)
   do 
      if (( $i<10 ))
         then
         sed "s/001/00${i}/g" PacBio-S6-$TISSUE-proovread-errorCorrection.job>delete.${TISSUE}.${i}.job
         sbatch delete.${TISSUE}.${i}.job
      elif (( $i>=10 )) && (( $i<100 ))
         then
         sed "s/001/0${i}/g" PacBio-S6-$TISSUE-proovread-errorCorrection.job>delete.${TISSUE}.${i}.job
         sbatch delete.${TISSUE}.${i}.job
      elif (( $i>=100 ))
         then
         sed "s/001/${i}/g" PacBio-S6-$TISSUE-proovread-errorCorrection.job>delete.${TISSUE}.${i}.job
         sbatch delete.${TISSUE}.${i}.job
    fi; 
done;
