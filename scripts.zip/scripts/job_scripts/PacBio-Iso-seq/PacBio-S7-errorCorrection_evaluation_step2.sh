### this script will get fmlrc read length distribution
for i in $(ls | grep fmlrc | grep Flnc.fa$)
  do
    tissue=$(echo $i | rev| cut -c 25- | rev)
    corrected_mean_length=$(perl -pe '/^>/ ? print "\n" : chomp' ${i} | tail -n +2 | awk '{if(NR%2==0) print length($0)}' | awk '{sum += $i; n++} END { if (n>0); print sum/n;}')
    noncorrected_mean_length=$(perl -pe '/^>/ ? print "\n" : chomp' ${tissue}.flnc.fasta | tail -n +2 | awk '{if(NR%2==0) print length($0)}' | awk '{sum += $i; n++} END { if (n>0); print sum/n;}')
# for single line fasta files:
#    noncorrected_mean_length=$(awk '{if(NR%2==0) print length($0)}' ${tissue}.unpolishedFl.fasta | awk '{sum +=$1;n++} END {if (n>0) print sum/n;}')
    echo ${tissue} ${noncorrected_mean_length} ${corrected_mean_length} >>flnc.fmlrc.read_length.dist
    echo $tissue "is done"
done;

# to summarize, issue:
# awk '{print $3/$2}' flnc.fmlrc.read_length.dist | awk '{sum +=$1;n++} END {if (n>0) print sum/n;}'
