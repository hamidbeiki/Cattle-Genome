# this will get list of chimeric reads detected by proovread in each tissue
ls | grep -f tissues |  grep  [0-9]-FLNC$>files
for i in $(ls | grep -f tissues |  grep  [0-9]-FLNC$)
   do
    cd ${i}
    tissue=$(echo $i | rev | cut -c 10- | rev)
    id=$(pwd | rev | sed 's/\-[a-z].*$//g; s/^.*\-//g' | rev)
    awk '{print $1}' ${tissue}-${id}-FLNC.chim.tsv | sort | uniq>chim
    grep '>' all.fa |  sed 's/>//g'>a
    cat a | grep -v -f chim >b
    grep 'CCS.[0-9]' b | sed 's/\.[0-9].*$//g' | sort | uniq -c | awk '$1>1 {print $2}' | sed 's/>//g' >nonchimeric-splitted_reads
    sed -i 's/ SUBSTR.*$//g' a
    cat chim nonchimeric-splitted_reads>c
    cat a | grep -v -f c >evaluation_reads
    rm -r a b c
    echo $i
   cd $(dirname $PWD)
done;


for tissue in $(cat tissues |  grep -v 'Liver_Domino\|Pool')
  do
    str="cat files | grep \${tissue} | awk '{print \$1,\"chim\"}' | sed 's/ /\//g' | tr '\n' ' ' | sed 's/^/cat /g'"
    cmd=$(eval $str)
    eval $cmd>${tissue}_proovread_chimeric_reads
    str="cat files | grep \${tissue} | awk '{print \$1,\"nonchimeric-splitted_reads\"}' | sed 's/ /\//g' | tr '\n' ' ' | sed 's/^/cat /g'"
    cmd=$(eval $str)
    eval $cmd>${tissue}_proovread_nonchimeric-splitted_reads
    cat ${tissue}_proovread_chimeric_reads ${tissue}_proovread_nonchimeric-splitted_reads >${tissue}_proovread_splitted_reads
    str="cat files | grep \${tissue} | awk '{print \$1,\"evaluation_reads\"}' | sed 's/ /\//g' | tr '\n' ' ' | sed 's/^/cat /g'"
    cmd=$(eval $str)
    eval $cmd>${tissue}_evaluation_reads
    echo $tissue
done;


softwares="/project/cattle_genome_assemblies/IsoSeq_analysis/Jreecy/softwares"
for tissue in $(cat tissues |  grep -v 'Liver_Domino\|Pool')
  do
    sed 's/CCS\..*$/CCS/g' ${tissue}_evaluation_reads >a
    $softwares/./ucsc-fasomerecords_377--h199ee4e_0.sif faSomeRecords ${tissue}_fmlrc_corrected_Flnc.fa a ${tissue}_fmlrc_corrected_Flnc.eval.fa
    $softwares/./ucsc-fasomerecords_377--h199ee4e_0.sif faSomeRecords ${tissue}_proovread_corrected_Flnc.fa ${tissue}_evaluation_reads ${tissue}_proovread_corrected_Flnc.eval.fa
    rm -r a
    echo $tissue
done;


methods=(proovread fmlrc) 
for method in "${methods[@]}";
  do 
   for tissue in $(cat tissues | grep -v 'Liver_Domino\|Pool')
     do
        echo $tissue $method
        corrected_mean_length=$(perl -pe '/^>/ ? print "\n" : chomp' ${tissue}_${method}_corrected_Flnc.eval.fa | tail -n +2 | awk '{if(NR%2==0) print length($0)}' | awk '{sum += $i; n++} END { if (n>0); print sum/n;}')
        noncorrected_mean_length=$(perl -pe '/^>/ ? print "\n" : chomp' ${tissue}.flnc.fasta | tail -n +2 | awk '{if(NR%2==0) print length($0)}' | awk '{sum += $i; n++} END { if (n>0); print sum/n;}')
        echo ${tissue} ${noncorrected_mean_length} ${corrected_mean_length} >>flnc.${method}.NonProvreadChim.read_length.dist
    done
done;
