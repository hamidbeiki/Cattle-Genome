### this will summarise error rates in different methods
echo "get error rates"
methods=(proovread fmlrc)
for method in "${methods[@]}";
  do
    echo "$method"
    for tissue in $(cat tissues_with_matched_RNAseq |  grep -v 'Liver_Domino\|Pool')
      do
        echo $tissue
            bash PacBio-S7-get_error_correction_error_rate.sh ${tissue} ${method} blasr>>flnc.${method}_error_rates
    done;
done;
