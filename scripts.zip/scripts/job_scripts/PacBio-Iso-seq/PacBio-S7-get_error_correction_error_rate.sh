### this program need to be run on a compute node to use the advantage of parallel processing, otherwise it will use 1 cpu
### to run this program issue: bash PacBio-S7-get_error_correction_error_rate.sh <your tissue, e.g Testes_Domino> <your error_correction method, e.g fmlrc> <your mapping method, e.g. blasr>
## input file
TISSUE="${1}"
CORRECTION_METHOD="${2}"
MAPPING_METHOD="${3}"

module load parallel
module load r 
#### get best match

get_most_likely_map(){
FILE=$1
awk '
    NR == FNR {
        if (!($1 in max) || $20 > max[$1])
            max[$1] = $20
        next
    }
    $20 == max[$1]
' "$FILE" "$FILE" >out2
}

awk 'BEGIN {OFS ="\t" } { $20 = $12- ($13+$14+$15) } 1' ${TISSUE}-uncorrected_${MAPPING_METHOD}_flnc_m5 >out

get_most_likely_map out

#### error rate computed as the ration of sum of the numbers of bases of insertions, deletions and substitutions to the total bases of matches
#uncorrected_error_rate=$(awk '{print ($13+$14+$15)/$12}' out2| awk '{sum +=$1;n++} END {if (n>0) print sum/n;}')
uncorrected_error_rate=$(awk '{print ($13+$14+$15)/$12}' out2 | ./median.R | awk '{print $2}')

awk 'BEGIN {OFS ="\t" } { $20 = $12- ($13+$14+$15) } 1' ${TISSUE}-corrected_${CORRECTION_METHOD}_${MAPPING_METHOD}_flnc_m5>out
get_most_likely_map out
#cat out2 | parallel --tmpdir /project/cattle_genome_assemblies/IsoSeq_analysis/Jreecy/Iso-seq/test  --pipe -N1500 grep -v -f  ${TISSUE}_proovread_chimeric_reads >out3
parallel -a out2 --pipepart grep -v -f  ${TISSUE}_proovread_chimeric_reads >out3

#corrected_error_rate=$(awk '{print ($13+$14+$15)/$12}' out3 | awk '{sum +=$1;n++} END {if (n>0) print sum/n;}')
corrected_error_rate=$(awk '{print ($13+$14+$15)/$12}' out3 | ./median.R | awk '{print $2}')
#corrected_mapped_length=$(awk '{sum +=$12;n++} END {if (n>0) print sum/n;}' out3)
corrected_mapped_length=$(awk '{print $12}' out3 | ./median.R | awk '{print $2}')
rm -r out out2 out3

#echo "uncorrected_error_rate" "corrected_error_rate"
echo $TISSUE $uncorrected_error_rate $corrected_error_rate $corrected_mapped_length
## use the following script to summarise all tissues results:
# for i in $(cat tissues_with_matched_RNAseq); do echo $i; bash PacBio-S6-get_error_correction_error_rate.sh ${i} fmlrc blasr>>fmlrc_error_rates;done
