### IMPORTANT: to speedup, this script need to be run on a compute node (i.e, run on a job script or reques
##  a compute node via: salloc -N1 -p brief-low -n 70 -t 015:00:00

# on nova
#module load python/3.6.3-u4oaxsb
#module load py-pandas/0.23.4-py3-sx6iffy

# on Ceres:
module load miniconda 
source activate /KEEP/cattle_genome_assemblies/bioconda/

INPUT_GFF="${1}"

awk '$3=="exon"' ${INPUT_GFF} | sed 's/gene\_id \"//g;s/\"\; /\t/g' | awk '{print $9, $4, $5}' >out
# to get whole gene length included intronic regions, issue: 
#sed 's/gene\_id \"//g;s/"; /\t/g' ${TISSUE}_${CORRECTION_METHOD}_corrected_Flnc.eval.collapsed.gff | awk '$3=="transcript"{print $9, $4, $5}'>out2

python get_Exonic_gene_length.py out >aa
mean_gene_length=$(awk 'NR==1' aa)
median_gene_length=$(awk 'NR==2' aa)

echo $TISSUE $CORRECTION_METHOD $mean_gene_length $median_gene_length
