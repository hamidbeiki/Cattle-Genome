#!/bin/sh
ls | grep .bas.h5 >allLibs
split -l 30 allLibs
for i in $(ls | grep ^x)
 do
  cp PacBio-S1-bax2bam.job PacBio-S1-bax2bam.${i}.job
  sed -i "s/xaa/${i}/g; s/\"bax2bam\"/\"${i}\"/g" PacBio-S1-bax2bam.${i}.job
  sbatch PacBio-S1-bax2bam.${i}.job
done;

