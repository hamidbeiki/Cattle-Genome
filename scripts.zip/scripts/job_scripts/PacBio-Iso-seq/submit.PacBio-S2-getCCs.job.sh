#!/bin/sh

cat allLibs | grep -vf failed_libs | grep -vf potentially_incorrect_protocol>allLibs_2
split -l 10 allLibs_2 s2_

for i in $(ls | grep ^s2)
 do
  cp PacBio-S2-getCCs.job PacBio-S2-getCCs.${i}.job
  sed -i "s/xaa/${i}/g; s/\"getCCs\"/\"${i}\"/g" PacBio-S2-getCCs.${i}.job
  sbatch PacBio-S2-getCCs.${i}.job
done;

