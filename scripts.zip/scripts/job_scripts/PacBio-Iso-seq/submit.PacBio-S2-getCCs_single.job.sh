#!/bin/sh

cat potentially_incorrect_protocol | grep -vf failed_libs>allLibs_3
num=0
for i in $(cat allLibs_3)
 do
  num=$((${num}+1))
  lib=$(echo $i | rev | cut -c 8- | rev);
  cp PacBio-S2-getCCs_single.job PacBio-S2-getCCs_single.${num}.job
  sed -i "s/input/${lib}/g; s/output/${lib}/g; s/\"getCCs\"/\"${num}\"/g" PacBio-S2-getCCs_single.${num}.job
  sbatch PacBio-S2-getCCs_single.${num}.job
done;

