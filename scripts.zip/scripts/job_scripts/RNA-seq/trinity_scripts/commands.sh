jid1=$(sbatch complete-commands.job)
jid1=$(echo $jid1 | sed 's/^.*job //g')
jida1=$(sbatch --depend=afterok:$jid1 assemble-transcripts.job)
jida1=$(echo $jida1 | sed 's/^.*job //g')
sbatch --depend=afterok:$jida1 edit4.job
jid2=$(sbatch --depend=afternotok:$jid1 edit1.job)
jid2=$(echo $jid2 | sed 's/^.*job //g')

jid3=$(sbatch --depend=afterok:$jid2 complete-commands.job)
jid3=$(echo $jid3 | sed 's/^.*job //g')
jida2=$(sbatch --depend=afterok:$jid3 assemble-transcripts.job)
jida2=$(echo $jida2 | sed 's/^.*job //g')
sbatch --depend=afterok:$jida2 edit4.job
jid4=$(sbatch --depend=afternotok:$jid3 edit2.job)
jid4=$(echo $jid4 | sed 's/^.*job //g')

jid5=$(sbatch --depend=afterok:$jid4 complete-commands.job)
jid5=$(echo $jid5 | sed 's/^.*job //g')
jida3=$(sbatch --depend=afterok:$jid5 assemble-transcripts.job)
jida3=$(echo $jida3 | sed 's/^.*job //g')
sbatch --depend=afterok:$jida3 edit4.job
jid6=$(sbatch --depend=afternotok:$jid5 edit3.job)
jid6=$(echo $jid6 | sed 's/^.*job //g')

jid7=$(sbatch --depend=afterok:$jid6 complete-commands.job)
jid7=$(echo $jid7 | sed 's/^.*job //g')

jid8=$(sbatch --depend=afterok:$jid7 assemble-transcripts.job)
jid8=$(echo $jid8 | sed 's/^.*job //g')
sbatch --depend=afterok:$jid8 edit4.job

jid9=$(sbatch --depend=afternotok:$jid7 edit5.job)
jid9=$(echo $jid9 | sed 's/^.*job //g')

jid10=$(sbatch --depend=afterok:$jid9 complete-commands.job)
jid10=$(echo $jid10 | sed 's/^.*job //g')
jid11=$(sbatch --depend=afterok:$jid10 assemble-transcripts.job)
jid11=$(echo $jid11 | sed 's/^.*job //g')
sbatch --depend=afterok:$jid11 edit4.job

jid12=$(sbatch --depend=afternotok:$jid10 edit5.job)
jid12=$(echo $jid12 | sed 's/^.*job //g')

jid13=$(sbatch --depend=afterok:$jid12 complete-commands.job)
jid13=$(echo $jid13 | sed 's/^.*job //g')

jid14=$(sbatch --depend=afterany:$jid13 assemble-transcripts.job)
jid14=$(echo $jid14 | sed 's/^.*job //g')

sbatch --depend=afterok:$jid14 edit4.job

