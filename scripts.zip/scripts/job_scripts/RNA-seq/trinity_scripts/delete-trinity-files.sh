#!/bin/sh

### to run issue: sbatch -p brief-low -N1 -n 70 -t 02:00:00 delete.sh
module load parallel

main=$PWD
for i in $(ls | grep completed);
 do
 echo $i 
 cd ${i}
 find . -type f>list
 time cat list | parallel  -N1000 "rm -r {}"
 cd $main
 rm -r ${i}
done;

