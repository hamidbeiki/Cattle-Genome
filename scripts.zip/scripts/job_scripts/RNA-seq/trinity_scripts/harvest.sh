for i in $(ls | grep comp)
   do
   cd ${i}
   mkdir /work/ABG/Hamid/Bos-taurus/Mammary-Illumina/transcriptome/${i}
   cp Trinity.fasta /work/ABG/Hamid/Bos-taurus/Mammary-Illumina/transcriptome/${i}
   cp Trinity.fasta.gene_trans_map /work/ABG/Hamid/Bos-taurus/Mammary-Illumina/transcriptome/${i}
  cd $(dirname $PWD)
done;
