for i in $(ls | grep .job$ | grep -f paired-HQC-stranded)
 do
  id=$(echo $i | rev | cut -c 5- | rev)
  mode=$(grep ${id} /lustre/project/cattle_genome_assemblies/IsoSeq_analysis/Jreecy/trinity/scripts/All.tissues.experiment.types | awk '{print $23}' | awk '{if ($1 =="fr-firststrand") print "RF"; else if ($1 =="fr-secondstrand") print "FR"}')
  sed -i "s/\-\-max/\-\-SS\_lib\_type ${mode} \-\-max/g" ${i}
done;

