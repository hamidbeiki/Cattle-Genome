counter=0
for i  in $(cat data)
 do
   oldid=$(tail -n 1 complete-commands.job | sed 's/perl.*mRNA\-trinity\///g;s/\-.*$//g')
   sed -i "s/${oldid}/${i}/g" complete-commands.job
   sed -i "s/${oldid}/${i}/g" assemble-transcripts.job
   counter=$((${counter}+1))
   sed -i "s/name\=\"s.*$/name\=\"s${counter}-grid\"/g" complete-commands.job
   echo "processing">process_status
   ./commands.sh
#   while [[ $(squeue -u beiki | awk '$1 !~/JOB/' | wc -l | awk '{print $1}')>0 ]]; do echo "processing $i"; done;
   j=1
   sp="/-\|" 
   while [[ $(grep processing process_status | wc -l)>0 ]]; do printf "\b${sp:j++%${#sp}:1}"; done;
   wait
done;

