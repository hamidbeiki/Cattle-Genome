#!/bin/sh

while [ true ]
do
 squeue -u james.reecy | grep -v 'Dependency\|NODES\|QOSMaxCpuPerUserLimit' | awk ' $5=="R" {running++}; $5!="R" {waiting++} END {printf "running_jobs=%d\trunning_percentage=%d%\n", running,(running/NR)*100}'
 sleep 10
done
